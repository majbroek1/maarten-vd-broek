/**
 * 
 */
package dataStorage;

import java.util.ArrayList;

import domain.Klant;

/**
 * @author Bob
 *
 */
public class KlantDAO {

	public static Klant getKlant(String	bsn) {
		// TODO
		return null;
	}
	
	public static void setKlant(Klant klant) {
		// TODO
	}
	
	public static void addKlant(Klant klant) {
		// TODO
	}
	
	public static ArrayList<Klant> getKlanten() {
		// TODO
		return null;
	}
	
}
