/**
 * 
 */
package dataStorage;

import java.util.ArrayList;

import domain.Afspraak;

/**
 * @author Bob
 *
 */
public class AfspraakDAO {

	private static final String FILE_XML = "Data/afspraken.xml";
	private static final String FILE_XSD = "Data/afspraken.xsd";
	
	public static Afspraak getAfspraak(int id) {
		// TODO
		return null;
	}
	
	public static void setAfspraak(Afspraak afspraak) {
		// TODO
	}
	
	public static void addAfspraak(Afspraak afspraak) {
		// TODO
	}
	
	public static ArrayList<Afspraak> getAfspraken() {
		// TODO
		return null;
	}
	
	public static ArrayList<Afspraak> getAfspraken(int behandelingId){
		// TODO
		return null;
	}
	
}
